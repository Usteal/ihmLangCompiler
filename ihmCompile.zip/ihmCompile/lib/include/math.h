//math.h

#ifndef MATH_H
#define MATH_h

int addInt(int a, int b, int c, int d);
int subtractInt(int a, int b, int c, int d);
int multiplyInt(int a, int b, int c, int d);
int devideInt(int a, int b, int c, int d);

float addFloat(float a, float b, float c, float d);
float subtractFloat(float a, float b, float c, float d);
float multiplyFloat(float a, float b, float c, float d);
float devideFloat(float a, float b, float c, float d);


#endif