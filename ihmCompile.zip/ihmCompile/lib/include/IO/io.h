//io.h
#include <string>

#ifdef IO_H
#define IO_H
//flow
typedef struct flow{
    void If((int a || float a || std::string a),
     (int b || float b || std::string b));
    void Else((int a || float a || std::string a),
    (int b || float b || std::string b));;
    void Elseif((int a || float a || std::string a),
    (int b || float b || std::string b));
};

flow flow;

#endif