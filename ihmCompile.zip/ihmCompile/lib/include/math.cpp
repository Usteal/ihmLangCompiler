#include "math.h"

//integers
int addInt(int a, int b, int c, int d){
    return a+b+c+d;
}
int subtractInt(int a, int b, int c, int d){
    return a-b-c-d;
}
int multiplyInt(int a, int b, int c, int d){
    return a*b*c*d;
}
int devideInt(int a, int b, int c, int d){
    return a*b*c*d;
}

//floats
float addFloat(float a, float b, float c, float d){
    return a+b+c+d;
}
float subtractFloat(float a, float b, float c, float d){
    return a-b-c-d;
}
float multiplyFloat(float a, float b, float c, float d){
    return a*b*c*d;
}
float devideFloat(float a, float b, float c, float d){
    return a*b*c*d;
}