// system.h

#ifndef system_h
#define system_h

int add(int a, int b);
int subtract(int a, int b);
#endif